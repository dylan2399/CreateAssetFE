import logo from './logo.svg';
import './App.css';
import CreateAsset from './components/CreateAsset';

function App() {
  return (
    <CreateAsset/>
  );
}

export default App;
