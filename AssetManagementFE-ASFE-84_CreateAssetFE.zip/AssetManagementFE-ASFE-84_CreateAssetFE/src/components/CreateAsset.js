import { validateDate, validateJoinedDate, validateName, validateType } from "../validation/validation";
import { Button, Form } from "react-bootstrap";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import checkIcon from "../assets/check.svg";
import errorIcon from "../assets/error.svg";
import ToastMessage from "../message/ToastMessage";
import UserService from "../services/UserService";
import moment from "momnet";




const CreateAsset = () => {
    const [toastList, setList] = useState([]);
    const showToast = (msg, type) => {
        switch (type) {
            case 'success':
                const toastSuccess = {
                    title: 'Success',
                    description: msg,
                    backgroundColor: '#5cb85c',
                    icon: checkIcon
                }
                setList([...toastList, toastSuccess]);
                break;
            case 'fail':
                const toastFail = {
                    title: 'Danger',
                    description: 'Failed: ' + msg,
                    backgroundColor: '#d9534f',
                    icon: errorIcon
                }
                setList([...toastList, toastFail]);
                break;
            default:
                break;
        }

    }

    const initialUserState = {
        firstName: "",
        lastName: "",
        dob: "",
        gender: "Male",
        joinedDate: "",
        type: ""
    };

    let navigate = useNavigate();

    const [newAsset, setNewAsset] = useState(initialUserState);

    const [touched, setTouched] = useState({
        firstName: false,
        lastName: false,
        dob: false,
        joinedDate: false,
        type: false
    });

    const handleInputChange = event => {
        const { name, value } = event.target;
        console.log(event.target.name + ": " + event.target.value);
        setNewAsset({ ...newAsset, [name]: value });
    };

    const handleBlur = evt => {
        setTouched({
            ...touched,
            [evt.target.name]: true
        })
    }

    const createAsset = (e) => {
        e.preventDefault();
        console.log(newAsset);
        UserService.create(newAsset)
            .then(response => {
                console.log(response.data);
                showToast('User was created successfully!', 'success');
                setTimeout(() => {
                    window.location.reload();
                    //navigate('/users');
                }, 2000);
            })
            .catch(e => {
                if (e.response.status == '401') {
                    showToast("Login with Admin Role is required to create Post", 'fail');
                }
                else {
                    showToast('Create failed with Status: ' + e.response.status, 'fail');
                    console.log(e);
                }
            });
    }

    const errorName = validateName(newAsset.Name);
   
    const errorDob = validateDate(newAsset.dob);
    const errorJoinedDate = validateJoinedDate(newAsset.joinedDate, newAsset.dob);
    const errorType = validateType(newAsset.type);

    const formValid = !errorName  && !errorDob && !errorJoinedDate && !errorType;

   
    return (
        <div className="container mt-5">
                 <h1> Create Asset</h1>
            <Form onSubmit={createAsset} validated={false}>
                <Form.Group className="mb-3">
                    <Form.Label> Name </Form.Label>
                    <Form.Control
                        required
                        name="Name"
                        value={newAsset.Name}
                        onChange={handleInputChange}
                        onBlur={handleBlur}
                        type="text"
                        isInvalid={touched.Name && Boolean(errorName)}
                        isValid={touched.Name && !Boolean(errorName)} />
                    <Form.Control.Feedback type="invalid">{errorName}</Form.Control.Feedback>
                    <Form.Control.Feedback type="valid"></Form.Control.Feedback>
                </Form.Group>


                <Form.Group className="mb-3">
                    <Form.Label className="mr-5"> Category </Form.Label>
                    
                    <Form.Select size="lg" aria-label="" name="type" style={{ width: "100%" }} onChange={handleInputChange}
                        isInvalid={touched.type && Boolean(errorType)}
                        isValid={touched.type && !Boolean(errorType)} 
                        onBlur={handleBlur}>
                        <option value=""></option>
                        <option value="loai1">1</option>
                        <option value="loai2">2</option>
                        <option value="loai3">3</option>
                        <option value="loai4">4</option>
                    </Form.Select>
                    <Form.Control.Feedback type="invalid">{errorType}</Form.Control.Feedback>
                    <Form.Control.Feedback type="valid"></Form.Control.Feedback>
                </Form.Group>
                <div>
                <Form.Label className="mr-5"> Specification </Form.Label>
                </div>
                <div>
                <textarea rows="4"  style={{ width: "100%" }}  name="comment" form="usrform" maxLength="100">
                </textarea>
                </div>
               
                
               
                
                <Form.Group className="mb-3">
                    <Form.Label>Joined Date</Form.Label>
                    <Form.Control
                        name="joinedDate"
                        value={newAsset.joinedDate}
                        onChange={handleInputChange}
                        onBlur={handleBlur}
                        type="date"
                        min={new Date('1900/01/02').toISOString().split("T")[0]}
                        maxDate={moment().format("mm/dd/yyyy")}
                        isInvalid={touched.joinedDate && Boolean(errorJoinedDate)}
                        isValid={touched.joinedDate && !Boolean(errorJoinedDate)} />
                    <Form.Control.Feedback type="invalid">{errorJoinedDate}</Form.Control.Feedback>
                    <Form.Control.Feedback type="valid"></Form.Control.Feedback>
                </Form.Group>
                
               


                <Form.Group className="mb-3">
                    <Form.Label>State</Form.Label>
                    <Form.Check className="ml-5"
                        defaultChecked
                        inline
                        label="Available"
                        type="radio"
                        name="State"
                        value="Available"
                        selected="selected"
                        onChange={handleInputChange} />
                    <Form.Check className="ml-5"
                        inline
                        label=" Not Available"
                        type="radio"
                        name="State"
                        value="Not Available"
                        onChange={handleInputChange} />
                </Form.Group>
                <Button disabled={!formValid} variant="danger"  type="submit">
                    Save
                </Button>
                <Button variant="light" className="btn btn-outline-secondary" type="button">
                    Cancel
                </Button>
            </Form><ToastMessage
                toastList={toastList}
                position="top-right"
                autoDelete={true}
                autoDeleteTime={3000} /></div>
    );
}

export default CreateAsset;